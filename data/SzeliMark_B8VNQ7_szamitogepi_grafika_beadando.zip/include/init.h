/* init.h file */

#ifndef INIT_H_
#define INIT_H_

/* Initialize the OpenGL context. */
void init_opengl();

#endif /* INIT_H_ */